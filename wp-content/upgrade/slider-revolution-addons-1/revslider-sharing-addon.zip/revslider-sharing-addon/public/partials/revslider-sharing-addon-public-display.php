<?php
/**
 * Provide a public-facing view for the plugin
 * @link       https://www.themepunch.com
 * @since      1.0.0
 *
 * @package    Revslider_Sharing_Addon
 * @subpackage Revslider_Sharing_Addon/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
